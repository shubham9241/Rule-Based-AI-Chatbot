# CodSoft Task 1 - Rule-Based AI Chatbot

## Overview
A simple rule-based chatbot developed in Python for the CodSoft Artificial Intelligence Internship.

## Features
- Handles greetings
- Answers basic questions
- Provides simple help
- Responds to thank-you messages
- Handles exit commands
- Uses predefined rules and pattern matching

## Technologies
- Python
- if/elif/else
- String processing
- Pattern matching

## How to Run
1. Install Python 3.
2. Open this folder in VS Code or a terminal.
3. Run:
   `python chatbot.py`
4. Type `bye`, `exit`, `quit`, or `goodbye` to stop.

## Example
You: hello
Bot: Hello! How can I help you?

You: what is your name
Bot: I am a Rule-Based AI Chatbot.

You: what can you do
Bot: I can answer basic questions using predefined rules.

You: bye
Bot: Goodbye! Have a nice day.

## Internship Task
CodSoft Artificial Intelligence Internship - Task 1: Chatbot with Rule-Based Responses.
