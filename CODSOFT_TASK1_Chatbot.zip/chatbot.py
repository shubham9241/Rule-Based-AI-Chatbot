def chatbot_response(user_input):
    user_input = user_input.lower().strip()

    if user_input in ["hello", "hi", "hey"]:
        return "Hello! How can I help you?"

    elif "how are you" in user_input:
        return "I'm doing great! Thanks for asking."

    elif "your name" in user_input:
        return "I am a Rule-Based AI Chatbot."

    elif "who are you" in user_input:
        return "I am a simple chatbot created using Python."

    elif "what can you do" in user_input:
        return "I can answer basic questions using predefined rules."

    elif "help" in user_input:
        return "Sure! You can ask me about my name, purpose, or basic information."

    elif "thank" in user_input:
        return "You're welcome!"

    elif user_input in ["bye", "goodbye", "exit", "quit"]:
        return "Goodbye! Have a nice day."

    else:
        return "Sorry, I don't understand that. Please try another question."


print("===================================")
print("       RULE-BASED AI CHATBOT")
print("===================================")
print("Type 'bye' to exit the chatbot.\n")

while True:
    user_input = input("You: ")
    response = chatbot_response(user_input)
    print("Bot:", response)

    if user_input.lower().strip() in ["bye", "goodbye", "exit", "quit"]:
        break
